package com.amdocs.property.exception;

@SuppressWarnings("serial")
public class PropertyException extends Exception{
	public PropertyException(String message) {
		super(message);
	}
}