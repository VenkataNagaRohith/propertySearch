package com.amdocs.property.exception;

@SuppressWarnings("serial")
public class InvalidContactNoException extends Exception{
	public InvalidContactNoException(String message) {
		super(message);
	}
}
